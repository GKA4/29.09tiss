let div    = document.querySelector('div');
let button = document.querySelector('#a');
let array = ["./ajax.html", "./ajax1.html", "./ajax2.html", "./ajax3.html", "./ajax4.html"];
let counter = 0;
q.addEventListener('click', async function() {
	const response = await fetch(array[counter]);
    const text = await response.text();
    div.innerHTML = text;
    counter++;
    if (counter === array.length){
        counter = 0;
    }
});